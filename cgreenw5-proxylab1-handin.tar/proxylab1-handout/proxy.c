#include <sys/types.h>
#include <sys/socket.h>
#include <sys/queue.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define BUF_SIZE 1024
#define NUM_THREADS 25

/* An array queue wasn't working so I'm using a regular queue lol */
// A linked list (LL) node to store a queue entry
struct QNode {
    int key;
    struct QNode* next;
};

// The queue, front stores the front node of LL and rear stores the
// last node of LL
struct Queue {
    struct QNode *front, *rear;
};

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

/* Semaphores for handling thread queues */
sem_t mutex, slots, items;

struct Queue* queue;

void echo(int connfd);
void *thread(void *vargp);
char* makeHttpRequest(char* inputBuf, int *serverPortNum, char* hostName);
char* sendRequest(char* request, int port, char* hostName, int* byteCount);
void sendResponse(int cfd, char* response, int byteCount);
struct QNode* newNode(int k);
struct Queue* createQueue();
void enQueue(struct Queue* q, int k);
int deQueue(struct Queue* q);

int main(int argc, char** argv)
{
    int port;
    int listenfd;
	socklen_t clientlen;
	struct sockaddr_in ip4addr;
	struct sockaddr_storage clientaddr;
	pthread_t tid[NUM_THREADS];

    if (argc < 2) {
        printf("Format must be './server <port_number>'\n");
        exit(EXIT_FAILURE);
    }
    else {
        port = atoi(argv[1]);
        printf("Port: %d\n", port);
    }

	/* Make the queue for client connections */
	queue = createQueue();

	/* Initialize queue semaphores */
	sem_init(&mutex, 0, 1);
	sem_init(&slots, 0, 20);
	sem_init(&items, 0, 0);

	/* Initialize Threads */
	for (int i = 0; i < NUM_THREADS; i++) {
		fprintf(stderr, "thread %d created\n", i);
		pthread_create(&tid[i], NULL, thread, NULL);
	}

    /* Open a listening socket on specified port */
    ip4addr.sin_family = AF_INET;
	ip4addr.sin_port = htons(atoi(argv[1]));
	ip4addr.sin_addr.s_addr = INADDR_ANY;
	if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket error");
		exit(EXIT_FAILURE);
	}
	if (bind(listenfd, (struct sockaddr*)&ip4addr, sizeof(struct sockaddr_in)) < 0) {
		close(listenfd);
		perror("bind error");
		close(listenfd);
		exit(EXIT_FAILURE);
	}
	if (listen(listenfd, 100) < 0) {
		close(listenfd);
		perror("listen error");
		exit(EXIT_FAILURE);
	} 

    /* Read data received from client */
    for (;;) {
		int cfd = accept(listenfd, (struct sockaddr *) &clientaddr, &clientlen);
		sem_wait(&slots);
		sem_wait(&mutex);
		enQueue(queue, cfd);
		sem_post(&mutex);
		sem_post(&items);
	}

    printf("Exiting normally\n");
    return 0;
}

/* Types of requests */
//GET http://example.com:49485/home.html HTTP/1.1
//GET http://example.com:49485 HTTP/1.1
//GET http://example.com HTTP/1.1
//GET http://example.com/home.html HTTP/1.1
char* makeHttpRequest(char* inputBuf, int *serverPortNum, char* hostName) {
	char method[MAX_OBJECT_SIZE], hostString[MAX_OBJECT_SIZE];
	char *host, *port;

	sscanf(inputBuf, "%s %s", method, hostString);
	char* hostUrl = hostString + 7; // Gets rid of the leading http://

	/* Split host/port and URI */
	char* hostAndPort = NULL;
	char* uri = NULL;
	char* hostUrl_copy = malloc(MAX_OBJECT_SIZE);
	strcpy(hostUrl_copy, hostUrl);
	if (strchr(hostUrl, '/') != NULL){
		hostAndPort = strtok(hostUrl_copy, "/");
		uri = hostUrl_copy + strlen(hostAndPort) + 1;
	}
	else {
		hostAndPort = hostUrl;
	}

	/* Split host/port into host and port */
	char* hostAndPort_copy = malloc(MAX_OBJECT_SIZE);
	strcpy(hostAndPort_copy, hostAndPort);
	if (strchr(hostAndPort_copy, ':') != NULL) {
		host = strtok(hostAndPort_copy, ":");
		port = strtok(NULL, ":");
		*serverPortNum = atoi(port);
	}
	else {
		host = hostAndPort;
	}

	memcpy(hostName, host, strlen(host));

	char* requestFirstLine = strtok(inputBuf, "\r\n");
	char* receivedHeaders = inputBuf + strlen(requestFirstLine) + 2;

	/* Exclude headers manually formulated in the HTTP request */
	char* keptHeaders = malloc(MAX_OBJECT_SIZE);
	char* line = strtok(receivedHeaders, "\r\n");
	while (line != NULL) {
		//Make sure one of the standard formulated headers isn't in the line
		//If it's not, append it to keptHeaders
		if (strstr(line, "Host") == NULL &&
		strstr(line, "Connection") == NULL &&
		strstr(line, "User-Agent") == NULL &&
		strstr(line, "Proxy-Connection") == NULL) {
			strcat(keptHeaders, strcat(line, "\r\n"));
		}
		line = strtok(NULL, "\r\n");
	}

	/* Make the HTTP Request */
	char* finalizedRequest = malloc(MAX_OBJECT_SIZE);
	strcat(finalizedRequest, "GET /");
	strcat(finalizedRequest, uri);
	strcat(finalizedRequest, " HTTP/1.0\r\n");
	
	strcat(finalizedRequest, "Host: ");
	strcat(finalizedRequest, host);
	strcat(finalizedRequest, "\r\n");

	strcat(finalizedRequest, user_agent_hdr);
	strcat(finalizedRequest, "Connection: close\r\n");
	strcat(finalizedRequest, "Proxy-Connection: close\r\n");

	strcat(finalizedRequest, keptHeaders);
	strcat(finalizedRequest, "\r\n");

	char* request = malloc(MAX_OBJECT_SIZE);
	memcpy(request, finalizedRequest, strlen(finalizedRequest));
	free(finalizedRequest);
	free(keptHeaders);
	free(hostAndPort_copy);
	free(hostUrl_copy);
	return request;
}

char* sendRequest(char* request, int port, char* hostName, int* byteCount){
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	int sfd, s/*, j*/;
	size_t len;
	ssize_t nread;
	char buf[MAX_OBJECT_SIZE];
	char* return_buf;
	char service[12]; 
	sprintf(service, "%d", port); /* Convert the port to a string service */

	/* Obtain address(es) matching host/port */

	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;    /* Allow IPv4 or IPv6 */
	hints.ai_socktype = SOCK_STREAM; /* TCP socket */
	hints.ai_flags = 0;
	hints.ai_protocol = 0;          /* Any protocol */

	s = getaddrinfo(hostName, service, &hints, &result);
	if (s != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(s));
		exit(EXIT_FAILURE);
	}

	/* getaddrinfo() returns a list of address structures.
	   Try each address until we successfully connect(2).
	   If socket(2) (or connect(2)) fails, we (close the socket
	   and) try the next address. */

	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket(rp->ai_family, rp->ai_socktype,
				rp->ai_protocol);

		if (sfd == -1)
			continue;

		if (connect(sfd, rp->ai_addr, rp->ai_addrlen) != -1)
			break;                  /* Success */

		close(sfd);
	}

	if (rp == NULL) {               /* No address succeeded */
		printf("could not connect...\n");
		exit(EXIT_FAILURE);
	}

	freeaddrinfo(result);           /* No longer needed */

	len = strlen(request) + 1; // +1 for null terminating byte

	if (write(sfd, request, len) != len) {
		fprintf(stderr, "partial/failed write\n");
		exit(EXIT_FAILURE);
	}

	while((nread = recv(sfd, buf + *byteCount, MAX_OBJECT_SIZE, 0)) > 0){
		*byteCount += nread;
	}
	return_buf = buf;
	free(request);

	return return_buf;
}

void sendResponse(int cfd, char* response, int byteCount){
	int numWritten = 0;
	int count = 0;
	while(count < byteCount) {
		numWritten = write(cfd, response + count, byteCount - count);
		count += numWritten;
	}
}

void *thread(void *vargp) 
{  
	pthread_detach(pthread_self()); //line:conc:echoservert:detach

	while(1) {
		sem_wait(&items);
		sem_wait(&mutex);
		int cfd = deQueue(queue);
		if (cfd < 0) continue; // There wasn't any connection in the queue
		sem_post(&mutex);

		/* Handle client connection */
		char buf[MAX_OBJECT_SIZE];
		int serverPortNum = 80; // Standard HTTP port by default
		char hostName[MAX_OBJECT_SIZE];

		/* Read all data from the client until it's done */
		int nread = 0, count = 0;
		while((nread = recv(cfd, buf + count, MAX_OBJECT_SIZE, 0)) > 0){
			count += nread;
			if (strstr(buf, "\r\n\r\n") != NULL) break;
		}
		
		if (nread == -1)
			return NULL;               /* Ignore failed request */

		char* formattedRequest = makeHttpRequest(buf, &serverPortNum, hostName);

		int byteCount = 0;
		char* response = sendRequest(formattedRequest, serverPortNum, hostName, &byteCount);
		sendResponse(cfd, response, byteCount);

		close(cfd);

		/* Open slot availability */
		sem_post(&slots);
	}
	
	return NULL;
}
  
// A utility function to create a new linked list node.
struct QNode* newNode(int k)
{
    struct QNode* temp = (struct QNode*)malloc(sizeof(struct QNode));
    temp->key = k;
    temp->next = NULL;
    return temp;
}
  
// A utility function to create an empty queue
struct Queue* createQueue()
{
    struct Queue* q = (struct Queue*)malloc(sizeof(struct Queue));
    q->front = q->rear = NULL;
    return q;
}
  
// The function to add a key k to q
void enQueue(struct Queue* q, int k)
{
    // Create a new LL node
    struct QNode* temp = newNode(k);
  
    // If queue is empty, then new node is front and rear both
    if (q->rear == NULL) {
        q->front = q->rear = temp;
        return;
    }
  
    // Add the new node at the end of queue and change rear
    q->rear->next = temp;
    q->rear = temp;
}
  
// Function to remove a key from given queue q
int deQueue(struct Queue* q)
{
    // If queue is empty, return NULL.
    if (q->front == NULL) {
        return -1;
	}

	int cfd = q->front->key;
  
    // Store previous front and move front one node ahead
    struct QNode* temp = q->front;
  
    q->front = q->front->next;
  
    // If front becomes NULL, then change rear also as NULL
    if (q->front == NULL)
        q->rear = NULL;
  
    free(temp);
	return cfd;
}